/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright by The HDF Group.                                               *
 * Copyright by the Board of Trustees of the University of Illinois.         *
 * All rights reserved.                                                      *
 *                                                                           *
 * This file is part of HDF5.  The full HDF5 copyright notice, including     *
 * terms governing use, modification, and redistribution, is contained in    *
 * the files COPYING and Copyright.html.  COPYING can be found at the root   *
 * of the source code distribution tree; Copyright.html can be found at the  *
 * root level of an installed copy of the electronic HDF5 document set and   *
 * is linked from the top-level documents page.  It can also be found at     *
 * http://hdfgroup.org/HDF5/doc/Copyright.html.  If you do not have          *
 * access to either file, you may request a copy from help@hdfgroup.org.     *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/*
 *   This program provides the storage information of an HDF5 chunking/contiguous dataset.
 *   For a chunked dataset, the number of chunks in an HDF5 dataset and the number of chunk dimensions, 
 *   the starting file address of a chunk, storage size of a chunk and the logical offset of this chunk are provided.
 *   For a contiguous dataset, the offset and the length of this HDF5 dataset are provided.
 */

#include <netcdf.h>
#include "hdf5.h"
#include <stdlib.h>
#include <string.h>

#define FILE_NAME "simple_nc4.nc"
/* We are writing 2D data, a 6 x 4 grid. */
#define NDIMS 2
#define NX 6
#define NY 4

int
main (int argc, char*argv[])
{
    hid_t       file;                        /* handles */
    hid_t       dataset;
    hid_t       cparms;
    H5D_layout_t data_layout;
    size_t      d_chunk_size;

    herr_t      status;
    char *      direct_filename;

    int ncid, x_dimid, y_dimid, varid1, varid2, grp1id, grp2id, typeid;
    int dimids[NDIMS];
    int nc_chunk_dims[NDIMS];
    size_t* chunk_offset;

    nc_chunk_dims[0] = NX;
    nc_chunk_dims[1] = NY;

#if 0
   /* This is the data array we will write. It will be filled with a
    * progression of numbers for this example. */
   unsigned long long data_out[NX][NY];

    for (int x = 0; x < NX; x++)
      for (int y = 0; y < NY; y++)
      {
         data_out[x][y] = x * NY + y;
      }
#endif
   /* Create the file. The NC_NETCDF4 flag tells netCDF to
    * create a netCDF-4/HDF5 file.*/
    if (nc_create(FILE_NAME, NC_NETCDF4|NC_CLOBBER, &ncid)<0) {
        printf("nc_create failed\n");
        return -1;
    }

   /* Define the dimensions in the root group. Dimensions are visible
    * in all subgroups. */
    if( nc_def_dim(ncid, "x", NX, &x_dimid) < 0) {
        nc_close(ncid);
        printf("nc_def_dim x failed\n");
        return -1;
    }
    if (nc_def_dim(ncid, "y", NY, &y_dimid) <0) {
        nc_close(ncid);
        printf("nc_def_dim x failed\n");
        return -1;
    }

   /* The dimids passes the IDs of the dimensions of the variable. */
   dimids[0] = x_dimid;
   dimids[1] = y_dimid;

    nc_def_var(ncid, "data", NC_INT, NDIMS,
                            dimids, &varid1);
    nc_def_var_chunking_direct_write(ncid, varid1, NC_CHUNKED, nc_chunk_dims);
    nc_def_var_deflate(ncid,varid1, 0, 1, 1);

    char dummy_buffer[1];
    nc_put_var(ncid, varid1, dummy_buffer);
#if 0
    nc_put_var_ulonglong(ncid, varid1, &data_out[0][0]);
    nc_close(ncid);
#endif

    if(argc !=3) {
        printf("Please provide the HDF5 file name and the HDF5 dataset name as the following:\n");
        printf(" ./h5dstoreinfo h5_file_name h5_dset_path .\n");
        return 0;
    }

    direct_filename = malloc(strlen(argv[1])+4);
    strncpy(direct_filename,"DC_",3);
    strncat(direct_filename,argv[1],strlen(argv[1]));
    printf ("direct_filename is %s\n",direct_filename);
    /*
     * Open the file and the dataset.
     */
    file = H5Fopen(argv[1], H5F_ACC_RDONLY, H5P_DEFAULT);
    if(file < 0) {
        printf("HDF5 file %s cannot be opened successfully,check the file name and try again.\n",argv[1]);
        return -1;
    }

    dataset = H5Dopen2(file, argv[2], H5P_DEFAULT);
    if(dataset < 0) {
        H5Fclose(file);
        printf("HDF5 dataset %s cannot be opened successfully,check the dataset path and try again.\n",argv[2]);
        return -1;
    }

    /*
     * Get creation properties list.
     */
    cparms = H5Dget_create_plist(dataset); /* Get properties handle first. */

    data_layout = H5Pget_layout(cparms);

    if (H5D_CHUNKED == data_layout)  {

        hid_t filespace;
        unsigned int dataset_rank;
        hsize_t* temp_coords;
        hsize_t* chunk_dims;
        hsize_t* max_dims;
        hsize_t* dims;

        int chunk_rank;
        hsize_t num_chunks;
        int i,j;


        hid_t out_file;
        hid_t out_dataset;

        hid_t out_dtype;
        hid_t out_mtype;
 
        printf("storage: chunked.\n");

        /* Get filespace handle first. */
        filespace = H5Dget_space(dataset);   
        dataset_rank = H5Sget_simple_extent_ndims(filespace);
#if 0
        dims = (hsize_t *)calloc(dataset_rank, sizeof(size_t));
        max_dims = (hsize_t *)calloc(dataset_rank, sizeof(size_t));
        H5Sget_simple_extent_dims(filespace, dims,max_dims);
#endif


        out_dtype = H5Dget_type(dataset);
        out_mtype = H5Tget_native_type(out_dtype,H5T_DIR_ASCEND);

        // Need to have a check to make sure out_dtype is the same as out_mtype.

        out_file = H5Fcreate (direct_filename, H5F_ACC_TRUNC, H5P_DEFAULT, H5P_DEFAULT);
        if (out_file <0) {
            printf("Cannot create the file %s\n",direct_filename);
            return -1;

        }
 
        out_dataset = H5Dcreate2(out_file, argv[2], out_dtype, filespace, H5P_DEFAULT, cparms, H5P_DEFAULT);
        if(out_dataset < 0) {
            printf("Cannot create the dataset %s\n",argv[2]);
            return -1;

        }

        chunk_dims = (hsize_t*)calloc(dataset_rank,sizeof(size_t));
        chunk_rank = H5Pget_chunk(cparms,dataset_rank,chunk_dims);
        printf("   Number of dimensions in a chunk is  %i\n",chunk_rank);
        for(i = 0; i <chunk_rank; i++) 
            printf(" Chunk Dim %d is %d\n",i,chunk_dims[i]);  
        temp_coords = (hsize_t*)calloc(chunk_rank,sizeof(size_t));

        chunk_offset = (size_t *)calloc(chunk_rank,sizeof(size_t));
        H5Dget_num_chunks(dataset,filespace,&num_chunks);
        printf("   Number of chunks is %llu\n",num_chunks);


        hid_t file_out;
        
        for(i = 0; i<num_chunks;i++) {

            haddr_t addr = 0;
            hsize_t size = 0;
 
            unsigned filter_mask = 0;
            H5Dget_chunk_info(dataset,filespace,i,temp_coords,&filter_mask,&addr,&size);
            char *buf = (char*)malloc(size);

            if (H5Dread_chunk(dataset,H5P_DEFAULT,temp_coords,&filter_mask,(void*)buf)<0) {
                printf("H5Dread_chunk read failed \n");
                free(buf);
                free(temp_coords);
                free(chunk_dims);
                free(direct_filename);
                H5Fclose(file);
                H5Fclose(out_file);
                return -1;
            }
 
            printf(" Filter_mask: %u\n",filter_mask);
            printf("    Chunk index:  %d\n",i);
            printf("    Number of bytes:  %u\n",size);
            printf("    Logical offset: offset");
            for (j=0; j<chunk_rank; j++) 
                printf("[%llu]",temp_coords[j]);
            printf("\n");
            printf("      Physical offset: %llu\n",addr); 
            printf("\n");

            for (j=0; j<chunk_rank; j++) {
                chunk_offset[j] = temp_coords[j];
            }


            if(H5Dwrite_chunk(out_dataset, H5P_DEFAULT, filter_mask, temp_coords, size, buf)<0) {
                printf("H5Dwrite_chunk write failed \n");
                free(buf);
                free(temp_coords);
                free(chunk_dims);
                free(direct_filename);
                H5Fclose(file);
                H5Fclose(out_file);
                return -1;
            }

            nc4_write_chunk(ncid, varid1, filter_mask, chunk_rank, chunk_offset, size, buf);
            free(buf);
        }
        free(temp_coords);
        free(chunk_offset);
        free(chunk_dims);
        H5Sclose(filespace);
        H5Tclose(out_dtype);
        H5Dclose(out_dataset);
        H5Fclose(out_file);

    }
    H5Pclose(cparms);
    H5Dclose(dataset);
    H5Fclose(file);
    nc_close(ncid);

    free(direct_filename);
    return 0;
}

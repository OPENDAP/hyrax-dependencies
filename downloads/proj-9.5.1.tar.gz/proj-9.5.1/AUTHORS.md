# Authors

## Original Author

- Gerald Evenden (1935-2016)

## Maintainers

- Kristian Evers <kreve@sdfi.dk>
- Even Rouault <even.rouault@spatialys.com>

## Project Steering Committee

Process and membership can be found at:
<https://proj.org/community/rfc/rfc-1.html>

Chair:

- Kristian Evers <kreve@sdfi.dk>

Members:

- Frank Warmerdam <warmerdam@pobox.com>
- Howard Butler <howard@hobu.co>
- Charles Karney <charles.karney@sri.com>
- Thomas Knudsen <thokn@sdfi.dk>
- Even Rouault <even.rouault@spatialys.com>
- Kurt Schwehr <schwehr@gmail.com>

## Contributors

The full list of contributors can be found on GitHub
<https://github.com/OSGeo/PROJ/graphs/contributors>
